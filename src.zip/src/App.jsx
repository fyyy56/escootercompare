import { useMemo, useState } from 'react';
import { SCOOTERS } from './data/scooters';
import { filterScooters, EMPTY_FILTERS } from './utils/filters';
import Header from './components/Header';
import BrandBar from './components/BrandBar';
import Catalog from './components/Catalog';
import FilterSidebar from './components/FilterSidebar';
import CompareBar from './components/CompareBar';
import CompareModal from './components/CompareModal';
import Footer from './components/Footer';

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeBrand, setActiveBrand] = useState('all');
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [selectedIds, setSelectedIds] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);

  const filteredScooters = useMemo(
    () =>
      filterScooters(SCOOTERS, {
        activeBrand,
        searchQuery,
        filters,
      }),
    [activeBrand, searchQuery, filters],
  );

  const compareItems = useMemo(
    () => selectedIds.map((id) => SCOOTERS.find((s) => s.id === id)).filter(Boolean),
    [selectedIds],
  );

  function toggleCompare(id) {
    setSelectedIds((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 4) return prev;
      return [...prev, id];
    });
  }

  function resetFilters() {
    setFilters(EMPTY_FILTERS);
    setActiveBrand('all');
    setSearchQuery('');
  }

  return (
    <>
      <Header searchQuery={searchQuery} onSearchChange={setSearchQuery} />
      <BrandBar activeBrand={activeBrand} onBrandChange={setActiveBrand} />

      <main>
        <div className="layout">
          <Catalog
            scooters={filteredScooters}
            selectedIds={selectedIds}
            onToggleCompare={toggleCompare}
          />
          <FilterSidebar
            filters={filters}
            onFilterChange={setFilters}
            onReset={resetFilters}
            resultCount={filteredScooters.length}
          />
        </div>
      </main>

      <CompareBar
        count={selectedIds.length}
        onClear={() => setSelectedIds([])}
        onCompare={() => setModalOpen(true)}
      />

      <CompareModal
        open={modalOpen}
        items={compareItems}
        onClose={() => setModalOpen(false)}
      />

      <Footer />
    </>
  );
}
