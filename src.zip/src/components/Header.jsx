export default function Header({ searchQuery, onSearchChange }) {
  return (
    <div className="hero">
      <div className="hero-inner">
        <div className="hero-brand">
          <img
            className="hero-icon"
            src="https://cdn-icons-png.flaticon.com/512/2972/2972185.png"
            alt=""
          />
          <h1>ESCOOTER COMPARE</h1>
        </div>
        <div className="search-box">
          <span className="search-icon">⌕</span>
          <input
            type="text"
            placeholder="Поиск по названию..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
      </div>
    </div>
  );
}
